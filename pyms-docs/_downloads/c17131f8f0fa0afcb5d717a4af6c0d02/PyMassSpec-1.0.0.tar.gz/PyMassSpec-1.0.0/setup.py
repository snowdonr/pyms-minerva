from setuptools import setup, find_packages

setup(
	name="PyMassSpec",
	version="1.0.0",
	packages=find_packages(),
	license="GNU General Public License v2.0",
	url="http://github.com/domdfcoding/pyms/",
	description="A Python toolkit for processing of chromatography--mass spectrometry data",
	long_description=open('README.rst').read(),
	install_requires=["numpy", "scipy", "matplotlib"],
)
